/*#include "cv.hpp"
#include <iostream>

using namespace std;
using namespace cv;

int main() {
	CascadeClassifier fullbody_classifier;
	vector<Rect> fullbodys;

	Mat frame, grayframe;
	
	//open video
	VideoCapture cap("background.mp4");
	double fps = cap.get(CV_CAP_PROP_FPS);

	//check video is open
	if (!cap.isOpened()) {
		cout << "Could not open video" << endl;
		return -1;
	}
	
	//fullbody detection configuration
	fullbody_classifier.load("C:/Users/NTH420/Downloads/opencv/sources/data/haarcascades/haarcascade_upperbody.xml");

	while (true) {
		//get a new frame from video
		cap >> frame;
		if (frame.empty()) {
			printf("break");
			break;
		}
	
		//convert captured frame to grayscale
		cvtColor(frame, grayframe, COLOR_BGR2GRAY);
		
		fullbody_classifier.detectMultiScale(
			grayframe,
			fullbodys,
			1.1, //increase search scale by 10% each pass
			3, //merge groups of three detections
			0, //not used for a new cascade
			Size(10, 10), //minsize
			Size(1000, 1000)
		);
		
		//draw result
		for (int i = 0; i < fullbodys.size(); i++) {
			Point lb(fullbodys[i].x + fullbodys[i].width, fullbodys[i].y + fullbodys[i].height);
			Point tr(fullbodys[i].x, fullbodys[i].y);
			rectangle(frame, lb, tr, Scalar(0, 255, 0), 3, 4, 0);
		}
		

		//print the output
		imshow("Number of people", frame);
		waitKey(1000 / fps);
	}


	return 0;
}






/*pedestrian - hog �̿�
int main() {	
	Mat frame;
	vector<Rect> found;
	int key; 

	//open video
	VideoCapture cap("background.mp4");
	double fps = cap.get(CV_CAP_PROP_FPS);

	//check video is open
	if (!cap.isOpened()) {
		cout << "Could not open video" << endl;
		return -1;
	}
	
	//detector(48*96 template)
	HOGDescriptor hog(
		Size(48,96),
		Size(16, 16),
		Size(8, 8),
		Size(8, 8),
		9
	);

	hog.setSVMDetector(HOGDescriptor::getDaimlerPeopleDetector());

	
	while (true) {
		//get a new frame from video
		cap >> frame;
		if (frame.empty())break;
		resize(frame,frame,Size(360, 288),0,0, CV_INTER_AREA);

		hog.detectMultiScale(
			frame,
			found,
			1.2,
			Size(8,8),
			Size(32,32),
			1.05,
			6
		);

		//draw result(bounding boxes);
		for (int i = 0; i < (int)found.size(); i++) {
			rectangle(frame, found[i], Scalar(0, 255, 0), 2);
		}

		//display
		imshow("Number of people", frame);
		key = waitKey(10);
		if (key == 27)break;
		else if (key == 32) {
			while ((key = waitKey(10) != 21 && key != 27)) {
				if (key == 27)break;
			}
		}
	}

	
	return 0;
}
*/